Sol Scobie c3302821

Apologies for the late submission I was chasing down bugs. 

I have used no Gen Ai in this assignment

To the best of my knowledge this should all be functional so lets hope that's true

A2 Update

To my testing the parser and symboltable are functional, error recovery is not in a great state, 
the system can sometimes recover but it's very state dependent, as far as I understand it always finds the first error correctly however

listingfiles are saved to the outputfolder, listingFileA1.txt and listingFileA2.txt should generate

