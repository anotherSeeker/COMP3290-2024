package Parser;
import Tokeniser.Token;
import java.util.*;

public class TokenParsers 
{
    public static void run(ArrayList<Token> tokenList)
    {
        
    }
}
