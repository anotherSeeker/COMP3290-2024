Sol Scobie c3302821

Apologies for the late submission I was chasing down bugs. 

I have used no Gen Ai in this assignment

To the best of my knowledge this should all be functional so lets hope that's true